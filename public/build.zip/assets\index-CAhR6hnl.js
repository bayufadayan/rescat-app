import{d as r,g as t}from"./app-GLbC7tYQ.js";var a=r();const e=t(a);export{e as R,a as r};
