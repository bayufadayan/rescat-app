import{j as e}from"./app-GLbC7tYQ.js";import{k as t}from"./index-DYYGe1al.js";import{B as n}from"./button-DnKWT2mF.js";import{H as i}from"./house-FzIN1zfw.js";import"./app-C5534Dzo.js";import"./utils-GyIXYEa3.js";import"./createLucideIcon-c8aNBYLN.js";function s(){return e.jsxs("div",{className:"relative w-full max-w-[880px] h-[400px] md:h-[380px] [perspective:1200px]",children:[e.jsx("figure",{className:"absolute top-4 -left-16 md:left-8 md:top-10 -rotate-[8deg] z-10",children:e.jsxs("div",{className:"relative w-[320px] h-[420px] rounded-2xl overflow-hidden shadow-xl shadow-black/25 ring-1 ring-white/30 ani-left",children:[e.jsx("img",{src:"/images/dummy/cat-original.png",alt:"cat-left",className:"absolute inset-0 h-full w-full object-cover select-none pointer-events-none"}),e.jsx("span",{"aria-hidden":!0,className:"absolute inset-0 rounded-2xl bg-blue-500/25 mix-blend-multiply"}),e.jsx("span",{"aria-hidden":!0,className:"absolute inset-0 rounded-2xl glow"}),e.jsx("span",{"aria-hidden":!0,className:"absolute inset-0 rounded-2xl shine delay-200"})]})}),e.jsx("figure",{className:"absolute top-0 left-1/2 -translate-x-1/2 rotate-0 z-30",children:e.jsxs("div",{className:"relative w-[320px] h-[420px] rounded-2xl overflow-hidden shadow-2xl shadow-black/35 ring-1 ring-white/40 ani-center",children:[e.jsx("img",{src:"/images/dummy/cat-original.png",alt:"cat-center",className:"absolute inset-0 h-full w-full object-cover select-none pointer-events-none"}),e.jsx("span",{"aria-hidden":!0,className:"absolute inset-0 rounded-2xl bg-blue-500/30 mix-blend-multiply"}),e.jsx("span",{"aria-hidden":!0,className:"absolute inset-0 rounded-2xl glow"}),e.jsx("span",{"aria-hidden":!0,className:"absolute inset-0 rounded-2xl shine delay-400"})]})}),e.jsx("figure",{className:"absolute top-4 -right-16 md:right-8 md:top-10 rotate-[8deg] z-20",children:e.jsxs("div",{className:"relative w-[320px] h-[420px] rounded-2xl overflow-hidden shadow-xl shadow-black/25 ring-1 ring-white/30 ani-right",children:[e.jsx("img",{src:"/images/dummy/cat-original.png",alt:"cat-right",className:"absolute inset-0 h-full w-full object-cover select-none pointer-events-none"}),e.jsx("span",{"aria-hidden":!0,className:"absolute inset-0 rounded-2xl bg-blue-500/25 mix-blend-multiply"}),e.jsx("span",{"aria-hidden":!0,className:"absolute inset-0 rounded-2xl glow"}),e.jsx("span",{"aria-hidden":!0,className:"absolute inset-0 rounded-2xl shine delay-600"})]})}),e.jsx("style",{children:`
        /* --- Keyframes --- */
        @keyframes bobbing {
          0%   { transform: translateY(0); }
          25%  { transform: translateY(-10px); }
          50%  { transform: translateY(-4px); }
          75%  { transform: translateY(-12px); }
          100% { transform: translateY(0); }
        }
        @keyframes driftX { 0% { transform: translateX(0) } 100% { transform: translateX(6px) } }
        @keyframes tilt { 0% { rotateY(-5deg) } 100% { rotateY(5deg) } }
        @keyframes pulseShadow { 0%,100% { box-shadow: 0 15px 40px rgba(0,0,0,.28) } 50% { box-shadow: 0 25px 60px rgba(0,0,0,.36) } }
        @keyframes glowA { 0%,100% { opacity:.18 } 50% { opacity:.35 } }
        @keyframes shineSweep { 0% { transform: translateX(-120%) } 100% { transform: translateX(120%) } }

        /* --- Combined Animations --- */
        .ani-left {
          animation:
            bobbing 7.8s ease-in-out infinite,
            driftX 9s ease-in-out infinite alternate,
            tilt 8s ease-in-out infinite alternate,
            pulseShadow 6s ease-in-out infinite;
          animation-delay: .8s, .2s, .3s, .5s;
          transform-style: preserve-3d;
        }
        .ani-center {
          animation:
            bobbing 6.4s ease-in-out infinite,
            tilt 7.2s ease-in-out infinite alternate,
            pulseShadow 5.5s ease-in-out infinite;
          animation-delay: .2s, .4s, .3s;
          transform-style: preserve-3d;
        }
        .ani-right {
          animation:
            bobbing 8.4s ease-in-out infinite,
            driftX 8.5s ease-in-out infinite alternate-reverse,
            tilt 9s ease-in-out infinite alternate,
            pulseShadow 6.2s ease-in-out infinite;
          animation-delay: 1.4s, .6s, .8s, .2s;
          transform-style: preserve-3d;
        }

        /* --- Glow & Shine --- */
        .glow {
          background: radial-gradient(50% 60% at 50% 60%, rgba(56,189,248,.35) 0%, rgba(56,189,248,.12) 55%, rgba(56,189,248,0) 80%);
          mix-blend-mode: screen;
          animation: glowA 3.8s ease-in-out infinite;
        }
        .shine {
          background: linear-gradient(100deg, transparent 0%, rgba(255,255,255,.12) 40%, rgba(255,255,255,.28) 50%, rgba(255,255,255,.12) 60%, transparent 100%);
          mix-blend-mode: screen;
          transform: translateX(-120%);
          animation: shineSweep 3.6s linear infinite;
        }

        .delay-200 { animation-delay: .2s; }
        .delay-400 { animation-delay: .4s; }
        .delay-600 { animation-delay: .6s; }
      `})]})}function u(){const a=t();return e.jsxs("div",{className:"min-h-dvh h-dvh flex items-center justify-center bg-[linear-gradient(to_bottom,_#0091F3,_#21A6FF)] relative overflow-hidden",children:[e.jsx("div",{className:"absolute hidden md:flex w-full h-full bg-[url('/images/background/pink-purple.png')] bg-cover bg-center bg-no-repeat mix-blend-soft-light"}),e.jsx("img",{src:"/images/background/onboard-pattern.png",alt:"onboarding-top-pattern",className:"absolute flex md:hidden inset-0 h-[30%] w-auto md:w-full md:h-[20%] object-cover mix-blend-screen opacity-50 object-left"}),e.jsxs("div",{className:"h-full w-full flex flex-col pt-8 px-8 z-10 gap-8 items-center",children:[e.jsx("div",{className:"flex justify-start items-center w-full text-white relative max-w-[880px]",children:e.jsx("button",{onClick:()=>window.location.href=a("home"),className:`\r
                            w-fit p-2.5 rounded-xl bg-white \r
                            shadow-[inset_0_2px_4px_rgba(0,0,0,0.15)]\r
                            hover:shadow-[inset_0_3px_6px_rgba(0,0,0,0.25)]\r
                            active:scale-95 transition-all duration-200 ease-out\r
                            border border-white/60\r
                            backdrop-blur-sm\r
                            cursor-pointer\r
                        `,children:e.jsx(i,{size:28,className:"text-neutral-800"})})}),e.jsxs("div",{className:"flex w-full max-w-[880px] flex-col gap-4 -mt-4",children:[e.jsxs("h1",{className:"font-extrabold text-white text-[55px] md:text-6xl leading-tight",children:["Makasihh yahh,"," ",e.jsx("span",{className:"relative inline-block -rotate-5",children:e.jsx("span",{className:`\r
                                    relative inline-flex items-center justify-center\r
                                    rounded-2xl px-4 py-2 md:px-5 md:py-2.5\r
                                    ring-1 ring-white/40 shadow-[0_10px_30px_rgba(14,165,233,.35)]\r
                                    bg-[radial-gradient(120%_140%_at_0%_0%,#9AE6FF_0%,#60A5FA_35%,#7C3AED_72%,#0EA5E9_100%)]\r
                                    before:absolute before:inset-0 before:rounded-2xl\r
                                    before:bg-[radial-gradient(120%_80%_at_30%_20%,rgba(255,255,255,.55),transparent)]\r
                                    before:opacity-70 before:pointer-events-none\r
                                    after:absolute after:-inset-px after:rounded-2xl after:bg-white/10 after:backdrop-blur-[1px]\r
                                    text-white tracking-tight select-none\r
                                `,children:e.jsx("span",{className:`\r
                                    relative z-10 font-extrabold\r
                                    bg-clip-text text-transparent\r
                                    bg-[linear-gradient(90deg,rgba(255,255,255,0.98),rgba(255,255,255,0.78),rgba(255,255,255,0.98))]\r
                                    bg-[length:200%_100%] animate-nick-shimmer\r
                                    drop-shadow-[0_0_14px_rgba(255,255,255,0.45)]\r
                                    `,children:"Cuyy!"})})})]}),e.jsx("style",{children:`
                        @keyframes nick-shimmer {
                            0%   { background-position: 0% 50%;    }
                            50%  { background-position: 100% 50%;  }
                            100% { background-position: 0% 50%;    }
                        }
                        .animate-nick-shimmer {
                            animation: nick-shimmer 3.2s ease-in-out infinite;
                        }
                    `}),e.jsx("p",{className:"text-white/95",children:"Kalau ngga ada kamu (nickname), ngga selesai kali nih aplikasi. Kalau ada feedback atau mau ngasih tau ada fitur error, isi feedback."}),e.jsx(n,{type:"button",className:"w-full bg-white text-black py-5 rounded-xl",tabIndex:4,"data-test":"login-button",onClick:()=>window.open("https://rescat.life/","_blank","noopener,noreferrer"),children:"Feedback (< 5 menit)"})]}),e.jsx("div",{className:"w-full flex justify-center items-center max-w-[880px] -z-10",children:e.jsx(s,{})})]})]})}export{u as default};
